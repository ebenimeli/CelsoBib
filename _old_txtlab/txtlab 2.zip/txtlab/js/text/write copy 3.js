export function initWriteMode() {
  const inputGoal    = document.getElementById("nwords");
  const goalWords    = document.getElementById("goalWords");
  const currentWords = document.getElementById("currentWords");
  const percWords    = document.getElementById("percWords");
  const progress     = document.getElementById("writeprogress");
  const textInput    = document.getElementById("itext");
  const timerEl      = document.getElementById("timer");
  const successDlg   = document.getElementById("success-dialog");

  // Botones de control del temporizador
  const btnPlay  = document.getElementById("timer-play");
  const btnPause = document.getElementById("timer-pause");

  let timer = null;
  let seconds = 0;
  let running = false;   // ← antes usábamos 'started'
  let goalReached = false;

  // HH:MM:SS
  function formatClock(s) {
    const h = String(Math.floor(s / 3600)).padStart(2, "0");
    const m = String(Math.floor((s % 3600) / 60)).padStart(2, "0");
    const sec = String(s % 60).padStart(2, "0");
    return `${h}:${m}:${sec}`;
  }

  // Duración "natural" para mensajes/compartir
  function formatNaturalDuration(s) {
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    const parts = [];
    if (h > 0) parts.push(`${h} h`);
    if (m > 0) parts.push(`${m} min`);
    if (sec > 0) parts.push(`${sec} s`);
    return parts.length ? parts.join(" ") : "0 s";
  }

  function updateTimerButtons() {
    if (!btnPlay || !btnPause) return;
    btnPlay.disabled  = running;
    btnPause.disabled = !running;
  }

  function startTimer() {
    if (running) return;
    running = true;
    timer = setInterval(() => {
      seconds++;
      timerEl.textContent = formatClock(seconds);
    }, 1000);
    updateTimerButtons();
  }

  function pauseTimer() {
    if (!running) return;
    clearInterval(timer);
    timer = null;
    running = false;
    updateTimerButtons();
  }

  function updateGoal() {
    const newGoal = parseInt(inputGoal.value, 10);
    if (!isNaN(newGoal) && newGoal > 0) {
      goalWords.textContent = newGoal;
      progress.max = newGoal;
    } else {
      goalWords.textContent = "0";
      progress.max = 0;
    }
    updateCurrent();
  }

  function updateCurrent() {
    const text = textInput.value.trim();
    const words = text === "" ? 0 : text.split(/\s+/).length;
    currentWords.textContent = words;

    const goal = parseInt(goalWords.textContent, 10) || 0;
    if (goal > 0) {
      const perc = Math.min((words / goal) * 100, 100);
      percWords.textContent = Math.round(perc) + " %";
      progress.value = words;

      // Si alcanza la meta, mostramos el modal y PAUSAMOS para fijar el tiempo
      if (words >= goal && !goalReached) {
        goalReached = true;
        pauseTimer();
        // Rellena datos del modal (si existe)
        const gEl = document.getElementById("success-goal");
        const tEl = document.getElementById("success-time");
        gEl && (gEl.textContent = goal);
        tEl && (tEl.textContent = formatNaturalDuration(seconds));
        successDlg?.showModal();
      }
    } else {
      percWords.textContent = "0 %";
      progress.value = 0;
    }
  }

  // Estado inicial
  inputGoal.value = "250";
  textInput.value = "";
  seconds = 0;
  timerEl.textContent = "00:00:00";
  updateGoal();
  updateTimerButtons();

  // Eventos
  inputGoal?.addEventListener("input", () => {
    goalReached = false;
    updateGoal();
  });

  textInput?.addEventListener("input", () => {
    updateCurrent();
    startTimer();            // empieza al escribir si no estaba corriendo
  });

  btnPlay?.addEventListener("click", startTimer);
  btnPause?.addEventListener("click", pauseTimer);
}


export function initWriteMode() {
  const inputGoal    = document.getElementById("nwords");
  const goalWords    = document.getElementById("goalWords");
  const currentWords = document.getElementById("currentWords");
  const percWords    = document.getElementById("percWords");
  const progress     = document.getElementById("writeprogress");
  const textInput    = document.getElementById("itext");
  const timerEl      = document.getElementById("timer");
  const successDlg   = document.getElementById("success-dialog");

  // Elementos del modal de éxito
  const successGoal  = document.getElementById("success-goal");
  const successTime  = document.getElementById("success-time");
  const shareX       = document.getElementById("share-x");
  const shareWA      = document.getElementById("share-wa");
  const shareMail    = document.getElementById("share-mail");

  const SITE_URL = "https://www.ebenimeli.org/txtlab/";

  let timer = null;
  let seconds = 0;
  let started = false;
  let goalReached = false; // evitar múltiples aperturas

  // HH:MM:SS para el visor
  function formatClock(s) {
    const h = String(Math.floor(s / 3600)).padStart(2, "0");
    const m = String(Math.floor((s % 3600) / 60)).padStart(2, "0");
    const sec = String(s % 60).padStart(2, "0");
    return `${h}:${m}:${sec}`;
  }

  // Duración "natural" para el mensaje/compartir
  // (horas si >0, minutos si >0, segundos si >0)
  function formatNaturalDuration(s) {
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    const parts = [];
    if (h > 0) parts.push(`${h} h`);
    if (m > 0) parts.push(`${m} min`);
    if (sec > 0) parts.push(`${sec} s`);
    return parts.length ? parts.join(" ") : "0 s";
  }

  function startTimer() {
    if (started) return;
    started = true;
    timer = setInterval(() => {
      seconds++;
      timerEl.textContent = formatClock(seconds);
    }, 1000);
  }

  function updateGoal() {
    const newGoal = parseInt(inputGoal.value, 10);
    if (!isNaN(newGoal) && newGoal > 0) {
      goalWords.textContent = newGoal;
      progress.max = newGoal;
    } else {
      goalWords.textContent = "0";
      progress.max = 0;
    }
    updateCurrent();
  }

  // Construye los enlaces de compartir con el texto requerido
  function updateShareLinks(goal, naturalTime) {
    const text = `🎉 ¡He alcanzado mi objetivo de escribir ${goal} palabras! He estado ${naturalTime} escribiendo con txtlab: ${SITE_URL} #thetxtlab #escribir #writing`;
    const enc  = encodeURIComponent(text);

    // X / Twitter
    if (shareX)  shareX.href  = `https://x.com/intent/tweet?text=${enc}`;

    // WhatsApp
    if (shareWA) shareWA.href = `https://api.whatsapp.com/send?text=${enc}`;

    // Email
    if (shareMail) {
      const subject = encodeURIComponent("¡Objetivo de escritura alcanzado!");
      shareMail.href = `mailto:?subject=${subject}&body=${enc}`;
    }
    // Facebook y LinkedIn ya comparten solo la URL por política de cada plataforma.
  }

  function updateCurrent() {
    const text = textInput.value.trim();
    const words = text === "" ? 0 : text.split(/\s+/).length;
    currentWords.textContent = words;

    const goal = parseInt(goalWords.textContent, 10) || 0;
    if (goal > 0) {
      const perc = Math.min((words / goal) * 100, 100);
      percWords.textContent = Math.round(perc) + " %";
      progress.value = words;

      // 🎉 Mostrar modal con datos cuando se alcanza el objetivo
      if (words >= goal && !goalReached) {
        goalReached = true;

        const natural = formatNaturalDuration(seconds);
        if (successGoal) successGoal.textContent = goal;
        if (successTime) successTime.textContent = natural;

        updateShareLinks(goal, natural);
        successDlg?.showModal();
      }
    } else {
      percWords.textContent = "0 %";
      progress.value = 0;
    }
  }

  // 👉 Valores iniciales al cargar
  inputGoal.value = "250";    // meta inicial
  textInput.value = "";       // textarea vacío
  timerEl.textContent = "00:00:00";   // icono de arena en tu HTML; dejamos vacío o HH:MM:SS si prefieres
  updateGoal();

  // Eventos
  inputGoal?.addEventListener("input", () => {
    goalReached = false; // reset al cambiar la meta
    updateGoal();
  });

  textInput?.addEventListener("input", () => {
    updateCurrent();
    startTimer();
  });
}
